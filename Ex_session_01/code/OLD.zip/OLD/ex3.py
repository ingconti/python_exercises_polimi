print("n:")
n = int(raw_input())

fact = 1
while n>1:
    fact*=n
    n-=1
        
print("fact: ", fact)

